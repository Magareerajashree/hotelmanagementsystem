package org.teca.hotel.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.teca.hotel.dao.BookingDAO;
import org.teca.hotel.dao.PaymentDao;
import org.teca.hotel.entity.BookingInformation;
import org.teca.hotel.entity.Payment;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class PaymentController {

	@Autowired
	public PaymentDao paymentdao;
	
	@Autowired
	public BookingDAO bookingdao;
	
	@RequestMapping("/payment")
	public void paymentDetails(Payment payment,HttpServletRequest request)
	{
		Payment paymentDetails=paymentdao.getPaymentDetails(payment);
		// System.out.println(payment);
		
	    BookingInformation information=(BookingInformation)request.getSession().getAttribute("bookinginformation");
		
	    bookingdao.bookingInfo(information);
	}
}
