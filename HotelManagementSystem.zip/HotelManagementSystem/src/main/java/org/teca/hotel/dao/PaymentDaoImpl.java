package org.teca.hotel.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.teca.hotel.entity.Payment;
import org.teca.hotel.repository.PaymentRepository;

@Component
public class PaymentDaoImpl implements PaymentDao{

	@Autowired
	public PaymentRepository paymentrepository;
	
	@Override
	public Payment getPaymentDetails(Payment information) {
	
		return paymentrepository.save(information);
		
	}

}
