package org.teca.hotel.entity;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class BookingInformation {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int bookindid;
	@Column(name="User_First_Name")
	private String firstname;
	@Column(name="User_Last_Name")
	private String lastname;
	@Column(name=" User_Email_Id", unique= true , nullable=false)
	private String emailid;
	@Column(name="User_Password",unique=true,nullable=false,length=10)
	private String mobilenumber;
	private LocalDate bookingdate;
	private String hotelname;
	private int noofdays;
	private int noofpersons;
	private int nofrooms;
	private double price;
	

}
