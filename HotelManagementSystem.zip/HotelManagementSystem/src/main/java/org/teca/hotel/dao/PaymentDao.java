package org.teca.hotel.dao;

import org.teca.hotel.entity.Payment;

public interface PaymentDao 
{
	Payment getPaymentDetails(Payment payment);
}

