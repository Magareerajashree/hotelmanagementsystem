package org.teca.hotel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.teca.hotel.dao.AdminDao;
import org.teca.hotel.entity.AdminInformation;
import org.teca.hotel.entity.HotelInformation;
import org.teca.hotel.entity.Payment;
import org.teca.hotel.entity.UserInformation;

@Controller
public class AdminController {
	
	@Autowired
	private AdminDao admindao;
	
	@RequestMapping("/adminlogin")
	public String getAdminLoginPage(Model model)
	{
		return "Adminlogin";
	}
	
	@RequestMapping("/showallusers")
	public String allUserDetails(Model model)
	{
		List<UserInformation> allUser=admindao.getAllUser();
		//System.out.println(allUser);
		
		model.addAttribute("UserDetails",allUser);
		return "UsersList";
	}
	
	@RequestMapping("/showallhoteldetails")
	public String allHotelDetails(Model model)
	{
		List<HotelInformation> allhotel=admindao.getAllHotel();
		System.out.println(allhotel);
		
		model.addAttribute("HotelDetails",allhotel);
		return "HotelList1";
		
	}
	
	@RequestMapping("/showallpaymentdetails")
	public String allPaymentDetails(Model model)
	{
		List<Payment> allpayment=admindao.getAllPaymentDetails();
		System.out.println(allpayment);
		
		model.addAttribute("PaymentDetails",allpayment);
		return "PaymentList1";
	}
	
	@RequestMapping("/admindetails")
	public String getAdminDetails(String emailid,@RequestParam("adminpassword")String password,Model model)
	{
		System.out.println(emailid);
		System.out.println(password);
		
		AdminInformation login =admindao.adminLogin(emailid, password);
		
		if(login !=null)
		{
			return "BookingDetails";
		}
		else
		{
			model.addAttribute("msg","InvalidDetails");
			return "AdminLogin";
		}
	}
	
	@RequestMapping("/getupdateid")
	public String getUpdateId(int id,Model model)
	{
		System.out.println(id);
		UserInformation userinformation=admindao.getUserById(id);
		model.addAttribute("user",userinformation);
	   System.out.println(userinformation);
	   return "UserDetailsUpdate";
	}
	
	@RequestMapping("/updated")
    String getUpdateDetails(UserInformation userinformation,Model model) //using model interface to transfer to java code to html code
    {
		UserInformation information=admindao.UpdateUserDetails(userinformation);
	    System.out.println(information);
	    List<UserInformation> alluser= admindao.getAllUser();
	    model.addAttribute("UserDetails",alluser);
	    return "UsersList";
    }

	@RequestMapping("/deleteUser")
	public String deleteUser(int id,Model model)
	{
		//System.out.println(id);
		admindao.deleteUserInformation(id);
		System.out.println("*********************UserInformation deleted****************");
		
		List<UserInformation> alluser=admindao.getAllUser();
		
		model.addAttribute("UserDetails",alluser);
		
		return "UsersList";
	}
	
	
	@RequestMapping("/gethotelupdateid")
	public String gethotelUpdateId(int id,Model model)
	{
		System.out.println(id);
		HotelInformation hotelinformation=admindao.getHotelById(id);
		model.addAttribute("hotel",hotelinformation);
	   System.out.println(hotelinformation);
	   return "HotelDetailsUpdate";
	}
	
	@RequestMapping("/hotelupdated")
    String getHotelUpdateDetails(HotelInformation hotelinformation,Model model) //using model interface to transfer to java code to html code
    {
		HotelInformation information=admindao.UpdateHotelDetails(hotelinformation);
	    System.out.println(information);
	    System.out.println("*****************************Updated Succesfully***************");
	    List<HotelInformation> allhotel= admindao.getAllHotel();
	    model.addAttribute("HotelDetails",allhotel);
	    return "HotelList1";
    }
	
	@RequestMapping("/deleteHotel")
	public String deleteHotel(int id,Model model)
	{
		//System.out.println(id);
		admindao.deleteHotelInformation(id);
		System.out.println("*********************HotelInformation deleted****************");
		
		List<HotelInformation> allhotel=admindao.getAllHotel();
		
		model.addAttribute("HotelDetails",allhotel);
		
		return "HotelList1";
	}
	
	
	
	
	
	
}
