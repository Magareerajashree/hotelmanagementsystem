package org.teca.hotel.controller;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.teca.hotel.dao.BookingDAO;
import org.teca.hotel.entity.BookingInformation;
import org.teca.hotel.entity.HotelInformation;
import org.teca.hotel.entity.UserInformation;

import jakarta.servlet.http.HttpServletRequest;


@Controller
public class BookingController {
	
	@Autowired
	private BookingDAO bookingDao;
	
	@RequestMapping("/bookingdetails")
	public String getBookingDetails(BookingInformation information,Model model,HttpServletRequest request)
	{
		BookingInformation bookinginfo=bookingDao.bookingInfo(information);
		System.out.println(bookinginfo);
		
		//LocalDate bookingdate=information.getBookingdate();
		request.getSession().setAttribute("bookinginformation", information);
		
		if(information.getBookingdate().isAfter(LocalDate.now())|| information.getBookingdate().isEqual(LocalDate.now()))
		{
			System.out.println(information);
			
			model.addAttribute("price", information.getPrice());
			
			
			return "AfterHotelPayment";
			
		}
		else
		{
			UserInformation userinformation=(UserInformation)request.getSession().getAttribute("user");
			model.addAttribute("user",userinformation);
			HotelInformation hotelInformation=(HotelInformation)request.getSession().getAttribute("hotel");
			model.addAttribute("hotelname",hotelInformation.getHotelname());
			model.addAttribute("price",hotelInformation.getPrice());
			model.addAttribute("msg","Invalid Details");
			return "BookHotel";
		}
	}

}
