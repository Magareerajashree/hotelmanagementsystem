package org.teca.hotel.dao;

import org.teca.hotel.entity.BookingInformation;

public interface BookingDAO {
	
	BookingInformation bookingInfo(BookingInformation bookingInformation);

}
