package org.teca.hotel.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.teca.hotel.dao.HotelDAO;
import org.teca.hotel.dao.UserDAO;
import org.teca.hotel.entity.HotelInformation;
import org.teca.hotel.entity.UserInformation;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class HotelController {
	
	
	@Autowired
	private HotelDAO hotelDAO;
	
	@RequestMapping("/hotelregister")
	public String hotelRegistrationPage(Model model)
	{
		HotelInformation information=new HotelInformation();
		model.addAttribute("hotelinformation",information);
		return "AddHotel";
	}
	
//	@RequestMapping("/hotelDetails")
//	@ResponseBody
//	public String hotelDetails(HotelInformation hotelInformation)
//	{
//		HotelInformation hotelregistration=hotelDAO.hotelRegistration(hotelInformation);
//		
//		if(hotelregistration!=null) 
//		{
//			
//			return "<h1>Registration Successfull!!.....<h1>";
//		}
//		else 
//		{
//			return "Invalid details";
//		}
//	}
	
	@RequestMapping("/hoteldetails")
	@ResponseBody
	public String hotelDetails(HotelInformation hotelInformation) 
	{
		
		HotelInformation hotelregistration=hotelDAO.hotelRegistration(hotelInformation);
		
		if(hotelregistration!=null) 
		{
			System.out.println("added");
			return "<h1>Registration Successfull!!.....<h1>";
		}
		else 
		{
			System.out.println("success");
			return "Invalid details";
		}
	}
	
	@RequestMapping("/gethotelbyid")
	public String getHotelId(int hotelid, HttpServletRequest  request,Model model) 
	{
		//System.out.println(hotelid);
		
		HotelInformation hotelinformation=hotelDAO.getHotelById(hotelid);
//		System.out.println(information);
		
		HttpSession session=request.getSession();
		UserInformation userinformation=(UserInformation) session.getAttribute("user");
		
		model.addAttribute("user",userinformation);
		
		session.setAttribute("hotel",hotelinformation);
		
		model.addAttribute("hotelname",hotelinformation.getHotelname());
		model.addAttribute("price",hotelinformation.getPrice());
		//System.out.println(information2);
		return "BookHotel";
	}
	
}


