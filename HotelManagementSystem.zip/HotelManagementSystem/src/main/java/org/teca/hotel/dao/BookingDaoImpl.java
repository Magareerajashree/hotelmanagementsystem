package org.teca.hotel.dao;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.teca.hotel.entity.BookingInformation;
import org.teca.hotel.repository.BookingRepository;

@Component
public class BookingDaoImpl implements BookingDAO{

	@Autowired
	private BookingRepository bookingRepository;
	
	@Override
	public BookingInformation bookingInfo(BookingInformation bookingInformation) {
		
		return bookingRepository.save(bookingInformation);
	}

	
}