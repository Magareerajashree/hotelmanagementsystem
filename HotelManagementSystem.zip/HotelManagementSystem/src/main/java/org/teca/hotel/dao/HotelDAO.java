package org.teca.hotel.dao;

import java.util.List;

import org.teca.hotel.entity.HotelInformation;
import org.teca.hotel.entity.UserInformation;

public interface HotelDAO {
	
	HotelInformation hotelRegistration(HotelInformation hotelInformation);
	
	List<HotelInformation> getAllHotelDetails();
	
	List<HotelInformation> getHotelDetailsByCity(String city);

	HotelInformation getHotelById(int hotelid);
}
