package org.teca.hotel.dao;

import java.util.List;

import org.teca.hotel.entity.AdminInformation;
import org.teca.hotel.entity.HotelInformation;
import org.teca.hotel.entity.Payment;
import org.teca.hotel.entity.UserInformation;

public interface AdminDao 
{

	AdminInformation adminLogin(String emailid,String password);
	
	List<UserInformation> getAllUser();
	
	List<HotelInformation> getAllHotel();
	
	List<Payment> getAllPaymentDetails();
	
	UserInformation getUserById(int id);
	
	UserInformation UpdateUserDetails(UserInformation userinformation);
	
	void deleteUserInformation(int id);
	
	
	HotelInformation getHotelById(int id);
	
    HotelInformation UpdateHotelDetails(HotelInformation hotelinformation);
	
	void deleteHotelInformation(int id);
}
