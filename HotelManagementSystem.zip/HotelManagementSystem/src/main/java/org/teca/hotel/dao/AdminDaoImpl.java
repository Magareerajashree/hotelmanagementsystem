package org.teca.hotel.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.teca.hotel.entity.AdminInformation;
import org.teca.hotel.entity.HotelInformation;
import org.teca.hotel.entity.Payment;
import org.teca.hotel.entity.UserInformation;
import org.teca.hotel.repository.AdminRepository;
import org.teca.hotel.repository.HotelRepository;
import org.teca.hotel.repository.PaymentRepository;
import org.teca.hotel.repository.UserRepository;

@Component
public class AdminDaoImpl implements AdminDao{

	@Autowired
	private AdminRepository adminrepository;
	
	@Autowired
	private UserRepository userrepository;
	
	@Autowired
	private HotelRepository hotelrepository;
	
	@Autowired
	private PaymentRepository paymentrepository;
	
	@Override
	public AdminInformation adminLogin(String emailid, String password) 
	{
		
		return adminrepository.findByAdminmailidAndAdminpassword(emailid, password);
	}
	
	@Override
	public List<UserInformation> getAllUser() {
		
		return userrepository.findAll();
	}

	@Override
	public List<HotelInformation> getAllHotel() {
		
		return hotelrepository.findAll();
	}

	@Override
	public List<Payment> getAllPaymentDetails() {
		
		return paymentrepository.findAll();
	}

	@Override
	public UserInformation getUserById(int id) {
		
		//return userrepository.findById(id).get(); (or)
		
		return userrepository.findById(id).orElse(new UserInformation());
		
	}

	@Override
	public UserInformation UpdateUserDetails(UserInformation userinformation) {
		return userrepository.save(userinformation);
	}
	
	@Override
	public void deleteUserInformation(int id) {
		 userrepository.deleteById(id);
	}
	
	

	@Override
	public HotelInformation UpdateHotelDetails(HotelInformation hotelinformation) {
		return hotelrepository.save(hotelinformation);
	}

	@Override
	public void deleteHotelInformation(int id) {
		hotelrepository.deleteById(id);
		
	}

	@Override
	public HotelInformation getHotelById(int id) {
		return hotelrepository.findById(id).orElse(new HotelInformation());

	}

	
	

}
	